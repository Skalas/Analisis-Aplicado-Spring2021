
import numpy as np
from numpy import linalg as LA
from derivadas import Grad, cuadrados, rosenbrock, Hess
from wolfe import genera_alpha
from act_bfgs import BFGS_Hk, DFP_Hk
from bfgs import BFGS
from gradiente_conjugado import gradiente_conjugado

##1) DFPS

arreglo=np.zeros(10)

for i in x0.len
    arreglo[i]=-10*i
end

x,k= BFGS(cuadrados, arreglo,1e-15,np.eye(4))) #Aquí, cambié el algoritmo de BFGS para que tenga el método DFP
print(f'Llegué a {x} en {k} iteraciones')

## Gradiente conjugado

import random
random.seed(152808) 
Diag_A = [random.randint(1,1000) for x in range(1000000)]
b = [random.randint(1,1000) for x in range(1000000)]


function B=reducida(A)
[n,m]=size(A);
B=zeros(n,n);
for i=1:n
    s=1;
    while s<m+1 && A(i,s+1)~=0
        B(i,A(i,s+1))=A(i,s);
        s=s+2;
    end
end

def gradiente_conjugado(x0, A, b):
    xk = x0
    b = np.matrix(b).T
    rk = np.dot(A, x0) - b
    pk = -rk
    while not (rk.T * rk ==  0):
        alphak = rk.T * rk / (pk.T * A * pk)
        alphak= alphak[0,0]
        xk_1 = xk + alphak * pk
        rk_1 =  rk + alphak * A * pk
        betak_1 = (rk_1.T * rk_1) / (rk.T * rk)
        betak_1 = betak_1[0,0]
        pk_1 = -rk_1 + betak_1 * pk
        xk, rk, pk = xk_1, rk_1, pk_1
    return xk

print(gradiente_conjugado(np.zeros(1000), reducido(Diag_A), b)