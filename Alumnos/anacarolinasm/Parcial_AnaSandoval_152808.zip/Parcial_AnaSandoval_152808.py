import numpy as np
import matplotlib.pyplot as plt
from numpy import linalg as LA
import random as ran

#Función Rosenbrock
a=1
b=100
fRosenbrock = lambda x,y: (a-x)**2 + b*(y-x**2)**2;

#Imprimir la función
pl.plot(x, y, fRosenbrock(x,y))
#aquí vemos que es difícil entontar el mínimo pues la función tiene un valle (concavidad) casi plana

#Def funciones grad y Hess
def grad(f, x0, h):
    n = len(x0)
    G = np.zeros(n)
    for i in range(n):
        z = np.zeros(n)
        z[i] += h
        xi = x0 + z
        G[i] = (f(xi) - f(x0))/h
    return G

def hess(f,x0,h):
    n = len(x0)
    s= (n,n)
    H = np.zeros(s)
    for i in range(n):
        for j in range(n):
            z1 = np.zeros(n)
            z2 = z1
            z1[i] += h
            z2[j] += h
            x1 = x0 + z1 + z2
            x2 = x0 + z1 - z2
            x3 = x0 - z1 + z2
            x4 = x0 - z1 - z2
            H[i,j] = (f(x1) - f(x2) - f(x3) + f(x4))/(4*(h**2))
    return H

#Usamos el algoritmo de Newton para encontrar el mínimo

#Newton
def MetNewton(f,x0,h,a): # Algoritmo de Newton
        xk =  x0
        n = len(xk)
        for k in range(1,100):
            Bk = hess(f,xk,h)
            pk = np.linalg.solve(Bk,-grad(f,xk,h))
            xk = xk + a*pk
        return xk

print(MetNewton(fRosenbrock, x0=0, h=0, a=1))

#Quasi-Newton
#No acabé :(